<?php
// Test runner for search_students.php
$_GET['q'] = 'test';
include __DIR__ . '/search_students.php';
